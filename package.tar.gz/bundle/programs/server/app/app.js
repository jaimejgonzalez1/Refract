var require = meteorInstall({"server":{"publications":{"projectsPublish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/projectsPublish.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.publish('Meteorusers', function (arrayOfIds) {                                                                 // 1
  // Validate the arguments to be what we expect                                                                      // 2
  // new SimpleSchema({                                                                                               // 3
  //   userIds: { type: [String] }                                                                                    // 4
  // }).validate({ userIds });                                                                                        // 5
  // Select only the users that match the array of IDs passed in                                                      // 6
  var selector = {                                                                                                    // 7
    _id: {                                                                                                            // 8
      $in: arrayOfIds                                                                                                 // 8
    }                                                                                                                 // 8
  }; // Only return one field, `initials`                                                                             // 7
  // const options = {                                                                                                // 11
  //   fields: { initials: 1 }                                                                                        // 12
  // };                                                                                                               // 13
  // return Meteor.users.find(selector);                                                                              // 14
                                                                                                                      //
  return Meteor.users.find(selector);                                                                                 // 15
}); // Meteor.publish('Meteor.users.all', function(userId) {                                                          // 16
//     return Meteor.users.find({});                                                                                  // 19
// });                                                                                                                // 20
                                                                                                                      //
Meteor.publish('projects', function () {                                                                              // 22
  return Projects.find();                                                                                             // 23
}); // from https://atmospherejs.com/reywood/publish-composite                                                        // 24
// Meteor.publishComposite('projects', function(_userId) {                                                            // 28
//     return {                                                                                                       // 29
//     find: function () {                                                                                            // 30
//         // return Projects.find({owner_id: _userId});                                                              // 31
//         return Projects.find();                                                                                    // 32
//                                                                                                                    // 33
//     }                                                                                                              // 34
//     , children: [                                                                                                  // 35
//         {                                                                                                          // 36
//             // passes in each individual project from the Projects collection                                      // 37
//             find: function (project) {                                                                             // 38
//                 // cross reference each project on the Users collection where _id in Users is equal to project.contributor
//                 return Users.find({                                                                                // 40
//                     profile: {                                                                                     // 41
//                     applied_projects: project._id                                                                  // 42
//                 }                                                                                                  // 43
//                 });                                                                                                // 44
//             }                                                                                                      // 45
//         }                                                                                                          // 46
//     , ]                                                                                                            // 47
// }                                                                                                                  // 48
// });                                                                                                                // 49
//                                                                                                                    // 50
// Meteor.publishComposite('projects_students', function(_userId) {                                                   // 51
//     return {                                                                                                       // 52
//     find: function () {                                                                                            // 53
//         return Projects.find();                                                                                    // 54
//     }                                                                                                              // 55
//     , children: [                                                                                                  // 56
//         {                                                                                                          // 57
//             // passes in each individual project from the Projects collection                                      // 58
//             find: function (project) {                                                                             // 59
//                 // cross reference each project on the Users collection where _id in Users is equal to project.contributor
//                 // return Users.find({                                                                             // 61
//                     // _id: project.contributor                                                                    // 62
//                 // });                                                                                             // 63
//             }                                                                                                      // 64
//         }                                                                                                          // 65
//     , ]                                                                                                            // 66
// }                                                                                                                  // 67
// });                                                                                                                // 68
// // Meteor.publishComposite('user_Skills', {                                                                        // 69
// //     // get the Projects collection - contains 'contributor' field which holds a user id from the Users collection
// //     find: function () {                                                                                         // 71
// //         return User_Skills.find();                                                                              // 72
// //     }                                                                                                           // 73
// //     , children: [                                                                                               // 74
// //         {                                                                                                       // 75
// //             // passes in each individual project from the Projects collection                                   // 76
// //             find: function (User_Skills) {                                                                      // 77
// //                 // cross reference each project on the Users collection where _id in Users is equal to project.contributor
// //                 return Users.find({                                                                             // 79
// //                     _id: user_skills.contributor                                                                // 80
// //                 });                                                                                             // 81
// //             }                                                                                                   // 82
// //         }                                                                                                       // 83
// //     , ]                                                                                                         // 84
// // });                                                                                                             // 85
// // Meteor.publishComposite('project_users', {                                                                      // 86
// //     // get the Projects collection - contains 'contributor' field which holds a user id from the Users collection
// //     find: function () {                                                                                         // 88
// //         return Project_Users.find();                                                                            // 89
// //     }                                                                                                           // 90
// //     , children: [                                                                                               // 91
// //         {                                                                                                       // 92
// //             // passes in each individual project from the Projects collection                                   // 93
// //             find: function (Project_Users) {                                                                    // 94
// //                 // cross reference each project on the Users collection where _id in Users is equal to project.contributor
// //                 return Users.find({                                                                             // 96
// //                     _id: project_users.contributor                                                              // 97
// //                 });                                                                                             // 98
// //             }                                                                                                   // 99
// //         }                                                                                                       // 100
// //     , ]                                                                                                         // 101
// // });                                                                                                             // 102
// // Meteor.publishComposite('project_users', {                                                                      // 103
// //     // get the Projects collection - contains 'contributor' field which holds a user id from the Users collection
// //     find: function () {                                                                                         // 105
// //         return Project_Users.find();                                                                            // 106
// //     }                                                                                                           // 107
// //     , children: [                                                                                               // 108
// //         {                                                                                                       // 109
// //             // passes in each individual project from the Projects collection                                   // 110
// //             find: function (Project_Users) {                                                                    // 111
// //                 // cross reference each project on the Users collection where _id in Users is equal to project.contributor
// //                 return Users.find({                                                                             // 113
// //                     _id: Users.contributor                                                                      // 114
// //                 });                                                                                             // 115
// //             }                                                                                                   // 116
// //         }                                                                                                       // 117
// //     , ]                                                                                                         // 118
// // });                                                                                                             // 119
// // Meteor.publishComposite('project_skills', {                                                                     // 120
// //     // get the Projects collection - contains 'contributor' field which holds a user id from the Users collection
// //     find: function () {                                                                                         // 122
// //         return Projects.find();                                                                                 // 123
// //     }                                                                                                           // 124
// //     , children: [                                                                                               // 125
// //         {                                                                                                       // 126
// //             // passes in each individual project from the Projects collection                                   // 127
// //             find: function (Projects) {                                                                         // 128
// //                 // cross reference each project on the Users collection where _id in Users is equal to project.contributor
// //                 return Users.find({                                                                             // 130
// //                     _id: project_skills.contributor                                                             // 131
// //                 });                                                                                             // 132
// //             }                                                                                                   // 133
// //         }                                                                                                       // 134
// //     , ]                                                                                                         // 135
// // });                                                                                                             // 136
// // Meteor.publishComposite('skills', {                                                                             // 137
// //     // get the Skills collection - contains 'contributor' field which holds a user id from the Users collection
// //     find: function () {                                                                                         // 139
// //         return Skills.find();                                                                                   // 140
// //     }                                                                                                           // 141
// // });                                                                                                             // 142
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":["meteor/meteor","meteor/accounts-base","./publications/projectsPublish.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor = void 0;                                                                                                  // 1
module.import('meteor/meteor', {                                                                                      // 1
    "Meteor": function (v) {                                                                                          // 1
        Meteor = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 0);                                                                                                                // 1
var Accounts = void 0;                                                                                                // 1
module.import('meteor/accounts-base', {                                                                               // 1
    "Accounts": function (v) {                                                                                        // 1
        Accounts = v;                                                                                                 // 1
    }                                                                                                                 // 1
}, 1);                                                                                                                // 1
module.import('./publications/projectsPublish.js');                                                                   // 1
Projects = new Mongo.Collection('projects');                                                                          // 6
Meteor.startup(function () {// code to run on server at startup                                                       // 8
});                                                                                                                   // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/publications/projectsPublish.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
